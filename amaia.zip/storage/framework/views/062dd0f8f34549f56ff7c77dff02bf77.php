<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\amaia\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>