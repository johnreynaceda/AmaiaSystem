<div>
    <?php if($counts > 0): ?>
        <?php if (isset($component)) { $__componentOriginal3f4792426b7364bb3dac7370e7314380 = $component; } ?>
<?php $component = WireUi\View\Components\Badge::resolve(['label' => ''.e($counts).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Badge::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['2xs' => true,'negative' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f4792426b7364bb3dac7370e7314380)): ?>
<?php $component = $__componentOriginal3f4792426b7364bb3dac7370e7314380; ?>
<?php unset($__componentOriginal3f4792426b7364bb3dac7370e7314380); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\amaia\resources\views/livewire/inbox-count.blade.php ENDPATH**/ ?>