<div>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\PROJECTS\amaia\resources\views/livewire/admin/amenities-list.blade.php ENDPATH**/ ?>