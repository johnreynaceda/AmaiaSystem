<div>
    <div class="mt-3 flex space-x-3 justify-center 2xl:justify-start items-center">
        <x-button label="Gate Pass" icon="document-text" class="font-semibold" positive />
        <x-button label="Visitor Pass" icon="document-text" class="font-semibold" positive />
    </div>
</div>
