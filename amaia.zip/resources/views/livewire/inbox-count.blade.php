<div>
    @if ($counts > 0)
        <x-badge label="{{ $counts }}" 2xs negative />
    @endif
</div>
