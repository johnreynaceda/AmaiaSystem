@section('title', 'Amenities')
<x-admin-layout>
    <div>
        <livewire:admin.amenities-list />
    </div>
</x-admin-layout>
