<div class="ml-3 flex flex-col py-0.5 space-y-1">
    <x-button label="CONTACT TENANT" xs class="font-semibold" teal />
    <x-button label="CONTACT COMPLAINEE" class="font-semibold" xs dark />
</div>
