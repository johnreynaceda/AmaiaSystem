@section('title', 'Unit Owner')
<x-admin-layout>
    <div>
        <livewire:admin.unit-owner-list />
    </div>
</x-admin-layout>
