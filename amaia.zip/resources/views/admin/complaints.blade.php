@section('title', 'Complaints')
<x-admin-layout>
    <div>
        <livewire:admin.complaint-list />
    </div>
</x-admin-layout>
