@section('title', 'Maintenance')
<x-admin-layout>
    <div>
        <livewire:admin.maintenance-list />
    </div>
</x-admin-layout>
