@section('title', 'Requests')
<x-admin-layout>
    <div>
        <livewire:admin.user-request />
    </div>
</x-admin-layout>
