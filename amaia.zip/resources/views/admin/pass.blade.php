@section('title', 'Pass')
<x-admin-layout>
    <div>
        <livewire:admin.pass-list />
    </div>
</x-admin-layout>
