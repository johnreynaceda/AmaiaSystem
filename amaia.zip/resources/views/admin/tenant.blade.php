@section('title', 'Tenant')
<x-admin-layout>
    <div>
        <livewire:admin.tenant-list />
    </div>
</x-admin-layout>
