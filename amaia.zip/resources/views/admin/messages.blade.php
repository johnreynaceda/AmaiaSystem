<x-admin-layout>
    <div>

        <livewire:admin.message-list />
    </div>
</x-admin-layout>
