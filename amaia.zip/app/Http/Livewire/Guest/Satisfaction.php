<?php

namespace App\Http\Livewire\Guest;

use Livewire\Component;

class Satisfaction extends Component
{
    public function render()
    {
        return view('livewire.guest.satisfaction');
    }
}
